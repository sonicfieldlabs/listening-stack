from __future__ import annotations

import json
import secrets
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from oida.conversation import ConversationStore
from oida.contracts import new_id, now_iso
from oida.listening_identity import ListeningIdentitySnapshot, ListeningIdentityStore
from oida.memory import AkousmataStore
from oida.reasoning.contracts import (
    EvidenceItem,
    EvidencePacket,
    ModelRole,
    ProviderLocality,
    ProviderResult,
    ReasoningProfile,
    ReasoningResponse,
    ReasoningSettings,
)
from oida.reasoning.deterministic import LocalStructuredProvider
from oida.reasoning.evidence import (
    EvidencePacketBuilder,
    covenant_blocks_untyped_prose,
    safe_external_text,
)
from oida.reasoning.prompts import CompiledPrompt, PromptCompiler, trusted_route_instructions
from oida.reasoning.providers.base import endpoint_locality
from oida.reasoning.registry import ProviderRegistry, build_provider_registry
from oida.reasoning.secrets import SecretStore
from oida.reasoning.settings import ReasoningSettingsStore
from oida.reasoning.validation import ResponseValidationError, ResponseValidator
from oida.relisten import RelistenUnavailable, TargetedRelistener


RegistryFactory = Callable[[ReasoningSettings], ProviderRegistry]


@dataclass(frozen=True)
class TurnOptions:
    provider_id: str | None = None
    model_id: str | None = None
    profile_id: str | None = None
    conversation_id: str | None = None
    comparison_events: list[dict[str, Any]] = field(default_factory=list)
    include_memory: bool = True
    include_transcript: bool | None = None
    include_memory_content: bool | None = None
    allow_targeted_relisten: bool | None = None
    research: dict[str, Any] = field(default_factory=dict)
    include_conversation_history: bool = True
    explicit_relisten: dict[str, Any] | None = None
    relisten_event: dict[str, Any] | None = None


def _inquiry_bound(provider_id):
    from oida.reasoning.bounded import BOUNDED_CONTEXT

    return (BOUNDED_CONTEXT.get(provider_id) or {}).get("inquiry_chars")


def _prepared_packet(packet, compiled):
    if compiled.included_evidence_refs is None:
        return packet  # Compatibility with an explicitly supplied legacy compiler.
    included = set(compiled.included_evidence_refs)
    return packet.model_copy(update={"items":[item for item in packet.items if item.ref in included]})


@dataclass
class _TurnContext:
    event: dict[str, Any]
    question: str
    options: TurnOptions
    settings: ReasoningSettings
    provider_id: str
    requested_provider_id: str
    model_id: str | None
    locality: ProviderLocality
    profile: ReasoningProfile
    packet: EvidencePacket
    compiled: CompiledPrompt
    route_instructions: str | None
    listening_identity: str
    listening_identity_snapshot: ListeningIdentitySnapshot
    memory_context: list[dict[str, Any]]
    include_transcript: bool
    include_memory_content: bool
    conversation_prepared: dict[str, Any]
    turn_id: str
    forced_fallback_reason: str | None = None
    relisten: dict[str, Any] | None = None


@dataclass
class _PreparedTurn:
    context: _TurnContext
    expires_monotonic: float
    stage: int = 0


class ReasoningOrchestrator:
    """Own prompt/evidence policy, provider execution, fallback, and commit.

    Provider adapters are deliberately dumb one-turn transports.  This layer
    is the only place that can choose a provider, repair once, run a single
    local targeted re-listen, or persist a final turn.
    """

    def __init__(
        self,
        *,
        settings_store: ReasoningSettingsStore,
        secret_store: SecretStore,
        conversations: ConversationStore,
        memory: AkousmataStore,
        listening_identity_store: ListeningIdentityStore | None = None,
        relistener: TargetedRelistener | None = None,
        registry_factory: RegistryFactory | None = None,
        prepare_ttl_seconds: float = 600.0,
        local_passages=None,
    ) -> None:
        self.settings_store = settings_store
        self.secret_store = secret_store
        self.conversations = conversations
        self.local_passages = local_passages
        self.memory = memory
        self.listening_identity_store = listening_identity_store
        self.relistener = relistener
        self.packet_builder = EvidencePacketBuilder()
        self.prompt_compiler = PromptCompiler()
        self.validator = ResponseValidator()
        self.local_provider = LocalStructuredProvider()
        self.registry_factory = registry_factory or (
            lambda settings: build_provider_registry(
                settings,
                secret_store=self.secret_store,
                local_provider=self.local_provider,
            )
        )
        self.prepare_ttl_seconds = max(60.0, float(prepare_ttl_seconds))
        self._prepared: dict[str, _PreparedTurn] = {}
        self._prepared_lock = threading.RLock()

    def ask(
        self,
        *,
        event: dict[str, Any],
        question: str,
        options: TurnOptions | None = None,
    ) -> dict[str, Any]:
        context = self._context(event=event, question=question, options=options or TurnOptions())
        from oida.research_recipes import active
        budget = active()
        if budget is not None:
            selected = {s["reference"] for s in context.options.research.get("sources",[]) if s.get("kind") in {"sonicfield","local_passage"}}
            prepared = {item.ref.removeprefix("context:") for item in _prepared_packet(context.packet,context.compiled).items if item.source in {"sonicfield","local_passage"}}
            if selected != prepared:
                from fastapi import HTTPException
                raise HTTPException(409,"Recipe selected context does not fit the prepared evidence packet")
        if context.options.explicit_relisten is not None:
            if budget is None:
                raise ValueError("An explicit research re-listen requires the bounded owner recipe")
            budget.stage("local_relisten")
            selected = context.options.explicit_relisten
            sidecar, error = self._perform_relisten(context, question=selected["question"],
                model_id=selected["model_id"],time_range={k:selected[k] for k in ("start_s","end_s")})
            if sidecar is None:
                from fastapi import HTTPException
                raise HTTPException(409,error or "Selected acoustic return unavailable")
            context.relisten = sidecar
            context.packet = _packet_with_relisten(context.packet,sidecar)
            context.compiled = self.prompt_compiler.compile(packet=context.packet,profile=context.profile,
                route_instructions=context.route_instructions,listening_identity=context.listening_identity,
                evidence_chars=_inquiry_bound(context.provider_id),conversation_history=[])
            relisten_ref = f"relisten:{sidecar.get('id')}:observation:0"
            if relisten_ref not in {item.ref for item in _prepared_packet(context.packet, context.compiled).items}:
                from fastapi import HTTPException
                raise HTTPException(409, "The selected re-listen does not fit this reasoner's evidence bound")
        if budget is not None:
            budget.stage("reason")
        response, execution = self._execute(context)
        return self._commit_context(context, response, execution=execution)

    def evaluate_retained(
        self, *, event, question, provider_id=None, require_model=True
    ):
        """Execute existing reasoning policy/validation without committing a turn.

        The caller owns cancellation and canonical report retention. This local
        route never opens raw audio or silently promotes deterministic fallback.
        """
        context = self._context(
            event=event,
            question=question,
            options=TurnOptions(
                provider_id=provider_id,
                include_memory=False,
                include_transcript=True,
                include_memory_content=False,
                allow_targeted_relisten=False,
            ),
        )
        if context.locality != ProviderLocality.LOCAL:
            raise ValueError(
                "Second-report execution requires a configured local provider"
            )
        if require_model and (
            context.provider_id == "local_structured" or context.forced_fallback_reason
        ):
            raise ValueError(
                "No configured local text model is available for this second-report pass"
            )
        response, execution = self._execute(context)
        if require_model and (
            execution.get("provider_id") == "local_structured"
            or execution.get("fallback")
        ):
            raise ValueError(
                "Second-report model failed; deterministic fallback is not a model pass"
            )
        return dict(
            response=response.model_dump(mode="json"),
            execution=execution,
            evidence_packet=_prepared_packet(context.packet, context.compiled).model_dump(mode="json"),
            pass_id=context.turn_id,
        )

    def prepare(
        self,
        *,
        event: dict[str, Any],
        question: str,
        options: TurnOptions | None = None,
    ) -> dict[str, Any]:
        context = self._context(event=event, question=question, options=options or TurnOptions())
        # prepare/commit is for the model already hosting the MCP tool.  A
        # local deterministic selection should use the daemon-managed ask path
        # instead of exporting a packet to an unselected host.
        if context.provider_id == "local_structured":
            raise ValueError("the active reasoner is daemon-managed; use oida_ask instead")
        self._check_local_context(context, external=True)
        token = self._issue_token(context, stage=0)
        return self._prepared_payload(token, context, stage=0)

    def commit_prepared(
        self,
        *,
        token: str,
        response: dict[str, Any] | str,
    ) -> dict[str, Any]:
        prepared = self._consume_token(token)
        context = prepared.context
        try:
            validated = self.validator.validate(
                response,
                packet=_prepared_packet(context.packet, context.compiled),
                allow_targeted_relisten=prepared.stage == 0 and self._relisten_allowed(context),
            )
        except ResponseValidationError:
            # A host-managed prepare/commit turn has no safe automatic way to
            # re-prompt the already-running host.  Reject it visibly rather
            # than persisting unvalidated output.
            raise

        if validated.requested_action is not None and prepared.stage == 0:
            sidecar, relisten_error = self._run_relisten(context, validated)
            if sidecar is not None:
                context.relisten = sidecar
                context.packet = _packet_with_relisten(context.packet, sidecar)
                context.compiled = self.prompt_compiler.compile(
                    packet=context.packet,
                    profile=context.profile,
                    route_instructions=context.route_instructions,
                    listening_identity=context.listening_identity,
                    evidence_chars=_inquiry_bound(context.provider_id),
                    conversation_history=[] if not context.options.include_conversation_history else self._history_for_packet(
                        context.options.conversation_id,
                        context.packet,
                        context.options.research.get("scope"),
                    ),
                )
                next_token = self._issue_token(context, stage=1)
                payload = self._prepared_payload(next_token, context, stage=1)
                payload.update(
                    {
                        "requires_followup": True,
                        "relisten": _public_relisten(sidecar),
                    }
                )
                return payload
            validated = _without_action(
                validated,
                relisten_error or "Targeted local re-listening was unavailable.",
            )
        elif validated.requested_action is not None:
            raise ResponseValidationError(["a second targeted re-listen is not permitted"])

        execution = {
            "selected_provider_id": context.provider_id,
            "provider_id": context.provider_id,
            "model_id": context.model_id,
            "locality": context.locality.value,
            "repaired": False,
            "attempts": 0,
            "host_managed": True,
            "fallback": None,
        }
        return self._commit_context(context, validated, execution=execution)

    def _context(self, *, event: dict[str, Any], question: str, options: TurnOptions) -> _TurnContext:
        normalized_question = " ".join(str(question or "").split()).strip()
        if not normalized_question:
            raise ValueError("conversation question is required")
        if len(normalized_question) > 16_000:
            raise ValueError("conversation question is too long")
        if not isinstance(event, dict) or not event.get("id"):
            raise ValueError("conversation requires a listening event")
        comparisons = list(options.comparison_events or [])
        if len(comparisons) > 3:
            raise ValueError("at most three comparison events may be attached")

        settings = self.settings_store.load()
        assignment = settings.roles[ModelRole.CONVERSATION]
        requested_provider = str(options.provider_id or assignment.provider_id or "local_structured")
        if options.model_id is not None:
            model_id = options.model_id
        elif options.provider_id is not None and options.provider_id != assignment.provider_id:
            model_id = None
        else:
            model_id = assignment.model_id
        profile_id = options.profile_id or settings.active_profile_id
        if profile_id not in settings.profiles:
            raise ValueError(f"unknown reasoning profile: {profile_id}")
        profile = settings.profiles[profile_id]
        incognito = str(event.get("privacy_mode") or "") == "incognito"

        forced_fallback: str | None = None
        selected_provider = requested_provider
        configured = settings.providers.get(requested_provider)
        if incognito and requested_provider != "local_structured":
            selected_provider = "local_structured"
            model_id = None
            forced_fallback = "Incognito mode forced local-only reasoning and disabled persistence."
        elif (
            requested_provider != "local_structured"
            and (configured is None or not configured.enabled)
            and not self._admitted_local_planner(requested_provider, settings)
        ):
            selected_provider = "local_structured"
            model_id = None
            forced_fallback = f"The selected provider {requested_provider!r} is not explicitly enabled."

        locality = _provider_locality(selected_provider, model_id, settings)
        memory_context = self.memory.similar_to_event(event, limit=3) if options.include_memory else []
        include_transcript = bool(
            _context_value(options.include_transcript, settings.include_transcript)
        ) and not incognito
        include_memory_content = bool(
            _context_value(options.include_memory_content, settings.include_memory_content)
        ) and not incognito
        packet = self.packet_builder.build(
            event=event,
            question=normalized_question,
            comparison_events=comparisons,
            memory_context=memory_context,
            include_transcript=include_transcript,
            include_memory_content=include_memory_content,
            references=[] if incognito else options.research.get("sources", []),
        )
        history = [] if incognito or not options.include_conversation_history else self._history_for_packet(options.conversation_id, packet, options.research.get("scope"))
        route_instructions = trusted_route_instructions(event)
        listening_identity_snapshot = self._listening_identity_snapshot()
        listening_identity = listening_identity_snapshot.text.strip()
        compiled = self.prompt_compiler.compile(
            packet=packet,
            profile=profile,
            route_instructions=route_instructions,
            listening_identity=listening_identity,
            conversation_history=history,
            evidence_chars=_inquiry_bound(selected_provider),
        )
        conversation_prepared = self.conversations.prepare(
            event=event,
            conversation_id=options.conversation_id,
        )
        context = _TurnContext(
            event=event,
            question=normalized_question,
            options=options,
            settings=settings,
            provider_id=selected_provider,
            requested_provider_id=requested_provider,
            model_id=model_id,
            locality=locality,
            profile=profile,
            packet=packet,
            compiled=compiled,
            route_instructions=route_instructions,
            listening_identity=listening_identity,
            listening_identity_snapshot=listening_identity_snapshot,
            memory_context=memory_context,
            include_transcript=include_transcript,
            include_memory_content=include_memory_content,
            conversation_prepared=conversation_prepared,
            turn_id=new_id("turn"),
            forced_fallback_reason=forced_fallback,
        )
        self._check_local_context(context)
        return context

    def _check_local_context(self, context, *, external=None):
        sources = context.options.research.get("sources", [])
        if not any(s.get("kind") == "local_passage" for s in sources):
            return
        from oida.local_passages import LocalPassageDenied
        if (self.local_passages is None or context.event.get("privacy_mode") == "incognito"
                or not context.options.research.get("scope", {}).get("local_passages")):
            raise LocalPassageDenied()
        # All offered snapshots will be retained. Only whole prepared items can
        # cross the selected provider boundary; withheld items never appear in metadata.
        self.local_passages.check_sources(sources,
            actions=("read", "read_metadata", "execute", "retain", "retain_metadata"))
        sent = {item.ref.removeprefix("context:")
                for item in _prepared_packet(context.packet, context.compiled).items
                if item.source == "local_passage"}
        remote = not self._local_passage_provider(context) if external is None else external
        self.local_passages.check_sources([s for s in sources if s.get("reference") in sent],
            actions=("read", "read_metadata", "execute"), external=remote)

    def _local_passage_provider(self, context):
        if context.provider_id == "local_structured":
            return True  # This path calls the built-in deterministic reasoner.
        # A persisted locality label or a host CLI's loopback transport does not
        # prove local inference. Inspect the selected endpoint without probing it.
        configured = context.settings.providers.get(context.provider_id)
        if context.provider_id != "local_ecology" and (configured is None or configured.kind.value not in {"ollama", "openai_compatible"}):
            return False
        if configured and configured.kind.value == "ollama" and str(context.model_id or "").lower().endswith("cloud"):
            return False
        adapter = self.registry_factory(context.settings).get(context.provider_id)
        endpoint = getattr(adapter, "base_url", None)
        try:
            return isinstance(endpoint, str) and endpoint_locality(endpoint) == "local"
        except ValueError:
            return False

    def _listening_identity_snapshot(self) -> ListeningIdentitySnapshot:
        if self.listening_identity_store is None:
            return ListeningIdentitySnapshot.empty()
        try:
            return self.listening_identity_store.snapshot()
        except (OSError, ValueError):
            # A malformed optional identity must not make listening or
            # grounded conversation unavailable. The editor endpoint still
            # exposes the file error so the operator can repair it.
            return ListeningIdentitySnapshot.empty()

    def _execute(self, context: _TurnContext) -> tuple[ReasoningResponse, dict[str, Any]]:
        self._check_local_context(context)
        if context.forced_fallback_reason:
            response = self.local_provider.answer(_prepared_packet(context.packet, context.compiled), profile=context.profile)
            return response, self._fallback_execution(context, context.forced_fallback_reason, attempts=0)

        registry = self.registry_factory(context.settings)
        response, result, repaired, errors, attempts = self._complete_with_repair(
            registry=registry,
            context=context,
            compiled=context.compiled,
            allow_targeted_relisten=self._relisten_allowed(context),
        )
        if response is None:
            reason = errors[-1] if errors else "The selected provider returned no valid structured response."
            local = self.local_provider.answer(_prepared_packet(context.packet, context.compiled), profile=context.profile)
            return local, self._fallback_execution(context, reason, attempts=attempts)

        execution = {
            "selected_provider_id": context.requested_provider_id,
            "provider_id": context.provider_id,
            "model_id": result.model_id if result is not None else context.model_id,
            "locality": context.locality.value,
            "repaired": repaired,
            "attempts": attempts,
            "host_managed": False,
            "fallback": None,
        }
        if response.requested_action is not None:
            sidecar, relisten_error = self._run_relisten(context, response)
            if sidecar is None:
                response = _without_action(
                    response,
                    relisten_error or "Targeted local re-listening was unavailable.",
                )
            else:
                context.relisten = sidecar
                context.packet = _packet_with_relisten(context.packet, sidecar)
                context.compiled = self.prompt_compiler.compile(
                    packet=context.packet,
                    profile=context.profile,
                    route_instructions=context.route_instructions,
                    listening_identity=context.listening_identity,
                    evidence_chars=_inquiry_bound(context.provider_id),
                    conversation_history=[] if not context.options.include_conversation_history else self._history_for_packet(
                        context.options.conversation_id,
                        context.packet,
                        context.options.research.get("scope"),
                    ),
                )
                response, final_result, final_repaired, errors, final_attempts = self._complete_with_repair(
                    registry=registry,
                    context=context,
                    compiled=context.compiled,
                    allow_targeted_relisten=False,
                    repair_allowed=not repaired,
                )
                execution["attempts"] = int(execution["attempts"]) + final_attempts
                execution["repaired"] = bool(execution["repaired"] or final_repaired)
                if response is not None:
                    execution["model_id"] = (
                        final_result.model_id if final_result is not None else execution["model_id"]
                    ) or execution["model_id"]
                else:
                    response = self.local_provider.answer(_prepared_packet(context.packet, context.compiled), profile=context.profile)
                    execution = self._fallback_execution(
                        context,
                        "The selected provider failed after the local re-listen: "
                        + (errors[-1] if errors else "invalid structured response"),
                        attempts=int(execution["attempts"]),
                    )
        return response, execution

    def _complete_with_repair(
        self,
        *,
        registry: ProviderRegistry,
        context: _TurnContext,
        compiled: CompiledPrompt,
        allow_targeted_relisten: bool,
        repair_allowed: bool = True,
    ) -> tuple[ReasoningResponse | None, ProviderResult | None, bool, list[str], int]:
        errors: list[str] = []
        result = registry.complete(self._provider_request(context, compiled, allow_relisten=allow_targeted_relisten))
        try:
            return (
                self.validator.validate_provider_result(
                    result,
                    packet=_prepared_packet(context.packet, compiled),
                    allow_targeted_relisten=allow_targeted_relisten,
                ),
                result,
                False,
                errors,
                1,
            )
        except ResponseValidationError as exc:
            errors.extend(exc.errors)

        if not repair_allowed:
            return None, result, False, errors, 1

        repair = self.prompt_compiler.repair_prompt(
            compiled=compiled,
            invalid_output=result.content or result.error or "",
            errors=errors,
        )
        repaired_result = registry.complete(
            self._provider_request(context, repair, allow_relisten=allow_targeted_relisten)
        )
        try:
            return (
                self.validator.validate_provider_result(
                    repaired_result,
                    packet=_prepared_packet(context.packet, repair),
                    allow_targeted_relisten=allow_targeted_relisten,
                ),
                repaired_result,
                True,
                errors,
                2,
            )
        except ResponseValidationError as exc:
            errors.extend(exc.errors)
            return None, repaired_result, True, errors, 2

    def _provider_request(
        self,
        context: _TurnContext,
        compiled: CompiledPrompt,
        *,
        allow_relisten: bool,
    ):
        self._check_local_context(context)
        effort = {"brief": "low", "balanced": "medium", "deep": "high"}.get(
            context.profile.depth.value,
            "medium",
        )
        return compiled.provider_request(
            provider_id=context.provider_id,
            model_id=context.model_id,
            metadata={
                "evidence_packet": _prepared_packet(context.packet, compiled).model_dump(mode="json"),
                "reasoning_effort": effort,
                "reasoning_profile": context.profile.model_dump(mode="json"),
                "allow_targeted_relisten": allow_relisten,
            },
        )

    def _run_relisten(
        self,
        context: _TurnContext,
        response: ReasoningResponse,
    ) -> tuple[dict[str, Any] | None, str | None]:
        if not self._relisten_allowed(context):
            return None, "Targeted local re-listening is disabled for this turn."
        if self.relistener is None:
            return None, "The local audio re-listening engine is unavailable."
        action = response.requested_action
        if action is None:
            return None, None
        return self._perform_relisten(context,question=action.question,time_range=action.time_range,
            model_id=context.settings.roles[ModelRole.TARGETED_RELISTEN].model_id)

    def _perform_relisten(self, context, *, question, time_range, model_id):
        if self.relistener is None:
            return None, "The local audio re-listening engine is unavailable."
        conversation = context.conversation_prepared["conversation"]
        try:
            sidecar = self.relistener.run(
                event=context.options.relisten_event or context.event,
                question=question,
                conversation_id=str(conversation["id"]),
                turn_id=context.turn_id,
                model_id=model_id,
                time_range=time_range,
                allow_speech_content=context.packet.permissions.transcript_included,
                parent_question=context.question,
                listening_identity_snapshot=context.listening_identity_snapshot,
            )
            sidecar = {
                **sidecar,
                # MOSS observations are free-form and may incidentally contain
                # spoken words. Transcript permission is therefore the only
                # structural gate that lets the observation enter another
                # prompt, response, or durable conversation.
                "observation_shared_to_reasoner": bool(context.packet.permissions.transcript_included),
            }
            return sidecar, None
        except RelistenUnavailable as exc:
            return None, str(exc)

    def _relisten_allowed(self, context: _TurnContext) -> bool:
        requested = context.options.allow_targeted_relisten
        if requested is None:
            requested = context.settings.allow_targeted_relisten
        return bool(requested)

    def _commit_context(
        self,
        context: _TurnContext,
        response: ReasoningResponse,
        *,
        execution: dict[str, Any],
    ) -> dict[str, Any]:
        self._check_local_context(context)
        response = response.model_copy(update={"requested_action": None})
        response_payload = response.model_dump(mode="json")
        fallback = execution.get("fallback")
        identity_applied = (
            context.listening_identity_snapshot.active
            and (
                bool(execution.get("host_managed"))
                or execution.get("provider_id") != "local_structured"
            )
        )
        identity_block = context.listening_identity_snapshot.event_block(
            application="conversation_prompt" if identity_applied else (
                "available_not_applied" if context.listening_identity_snapshot.active else "inactive"
            ),
            applied_to=["grounded_conversation"] if identity_applied else [],
        )
        turn = {
            "id": context.turn_id,
            "created_at": now_iso(),
            "question": context.question,
            "answer": response.answer,
            **response_payload,
            "known_facts": [
                block.text for block in response.answer_blocks if block.kind in {"fact", "answer"}
            ],
            "uncertainty_notes": list(response.uncertainties),
            "evidence": [_legacy_evidence(item) for item in _prepared_packet(context.packet, context.compiled).items],
            "memory_context": [_memory_context_item(item) for item in context.memory_context],
            "provider": execution["provider_id"],
            "reasoner": {
                "provider_id": execution["provider_id"],
                "selected_provider_id": execution["selected_provider_id"],
                "model_id": execution.get("model_id"),
                "locality": execution["locality"],
                "repaired": bool(execution.get("repaired")),
                "host_managed": bool(execution.get("host_managed")),
                "attempts": int(execution.get("attempts") or 0),
            },
            "fallback": fallback,
            "relisten": _public_relisten(context.relisten) if context.relisten else None,
            "remote_model": {
                "enabled": execution["provider_id"] != "local_structured",
                "requested": context.requested_provider_id != "local_structured",
                "provider": context.requested_provider_id,
                "note": (
                    fallback.get("note")
                    if isinstance(fallback, dict)
                    else "The selected reasoner returned a validated event-grounded response."
                ),
            },
            "audit": {
                "evidence_contract": context.packet.contract,
                "evidence_refs": [item.ref for item in _prepared_packet(context.packet, context.compiled).items],
                "offered_evidence_refs": [item.ref for item in context.packet.items],
                "withheld_evidence_refs": list(context.compiled.withheld_evidence_refs),
                # Retain the actual bounded values, not a reconstruction from the source
                # snapshots. Existing local-passage retention checks apply to this turn.
                "research_evidence_shown": [
                    item.model_dump(mode="json")
                    for item in _prepared_packet(context.packet, context.compiled).items
                    if item.source in {"sonicfield", "local_passage"} or item.kind == "relisten"
                ],
                "prompt_hash": context.compiled.prompt_hash,
                "listening_identity": identity_block,
                "profile_id": context.profile.id,
                "comparison_event_ids": list(context.packet.comparison_event_ids),
                "transcript_included": context.packet.permissions.transcript_included,
                "memory_content_included": context.packet.permissions.memory_content_included,
                "raw_audio_external": False,
                "targeted_relisten_count": 1 if context.relisten else 0,
                # Shared means the reasoner received it: permitted and inside the bounded packet.
                "relisten_observation_shared_to_reasoner": bool(
                    context.relisten
                    and context.relisten.get("observation_shared_to_reasoner")
                    and f"relisten:{context.relisten.get('id')}:observation:0"
                    in {item.ref for item in _prepared_packet(context.packet, context.compiled).items}
                ),
            },
        }
        if context.options.research:
            turn["research"] = dict(context.options.research)
            if context.options.explicit_relisten and context.relisten and turn["research"].get("comparison"):
                turn["research"]["comparison"] = {**turn["research"]["comparison"],"acoustic_access":"one local targeted pass recorded; initial retained account unchanged"}
            if context.options.research.get("exposure") is not None:
                from oida.research_references import ResearchContext
                exposure = ResearchContext.model_validate(context.options.research["exposure"])
                sent = {item.ref.removeprefix("context:") for item in _prepared_packet(context.packet, context.compiled).items
                        if item.source == "sonicfield"}
                prepared = [ref for ref in exposure.reference_refs if ref in sent]
                withheld = [ref for ref in exposure.reference_refs if ref not in sent]
                turn["research"]["exposure"] = ResearchContext.model_validate(exposure.model_dump() | dict(
                    context_basis="informed_context" if prepared else "selected_context",
                    prepared_reference_refs=prepared, withheld_reference_refs=withheld,
                )).model_dump()
            if context.options.research.get("local_exposure") is not None:
                from oida.local_passages import LocalExposure
                exposure = LocalExposure.model_validate(context.options.research["local_exposure"])
                sent = {item.ref.removeprefix("context:") for item in _prepared_packet(context.packet, context.compiled).items
                        if item.source == "local_passage"}
                prepared = [ref for ref in exposure.reference_refs if ref in sent]
                turn["research"]["local_exposure"] = LocalExposure.model_validate(exposure.model_dump() | dict(
                    context_basis="informed_context" if prepared else "selected_context",
                    prepared_reference_refs=prepared,
                    withheld_reference_refs=[ref for ref in exposure.reference_refs if ref not in sent],
                )).model_dump()
        from oida.operation_control import checkpoint
        from oida.research_recipes import finalize
        finalize(turn, context.conversation_prepared["stored_event"])
        checkpoint(seal=True)
        prepared = context.conversation_prepared
        result = self.conversations.append_turn(
            event=context.event,
            stored_event=prepared["stored_event"],
            turn=turn,
            conversation=prepared["conversation"],
            persistent=bool(prepared["persistent"]),
            raw_audio_policy=str(prepared["raw_audio_policy"]),
            comparison_event_ids=list(context.packet.comparison_event_ids),
            comparison_events=[
                _redacted_comparison(value) for value in context.options.comparison_events
            ],
        )
        result["forbidden_topics_triggered"] = []
        return result

    def _fallback_execution(
        self,
        context: _TurnContext,
        reason: str,
        *,
        attempts: int,
    ) -> dict[str, Any]:
        note = _bounded_error(reason)
        return {
            "selected_provider_id": context.requested_provider_id,
            "provider_id": "local_structured",
            "model_id": self.local_provider.model_id,
            "locality": "local",
            "repaired": attempts > 1,
            "attempts": attempts,
            "host_managed": False,
            "fallback": {
                "used": True,
                "from_provider_id": context.requested_provider_id,
                "to_provider_id": "local_structured",
                "note": note,
            },
        }

    def _conversation_history(
        self,
        conversation_id: str | None,
        *,
        allow_transcript: bool,
        allow_memory_content: bool,
        context_scope: dict | None = None,
    ) -> list[dict[str, str]]:
        if not conversation_id:
            return []
        try:
            conversation = self.conversations.get(conversation_id)
        except (FileNotFoundError, ValueError):
            return []
        history: list[dict[str, str]] = []
        for turn in list(conversation.get("turns") or [])[-6:]:
            if not isinstance(turn, dict):
                continue
            # Private context is never replayed implicitly, even to another local
            # model. A fresh explicit selection is required for every inquiry.
            if any(s.get("kind") == "local_passage" for s in (turn.get("research") or {}).get("sources", [])):
                continue
            previous_scope = (turn.get("research") or {}).get("scope", {})
            if any(previous_scope.get(key) and not (context_scope or {}).get(key) for key in ("web", "wiki", "memories", "sonicfield")):
                continue
            audit = turn.get("audit") if isinstance(turn.get("audit"), dict) else None
            if audit is None and (not allow_transcript or not allow_memory_content):
                # Legacy turns have no provenance flags. Do not replay them
                # across a stricter current disclosure boundary.
                continue
            if audit is not None and (
                (bool(audit.get("transcript_included")) and not allow_transcript)
                or (bool(audit.get("memory_content_included")) and not allow_memory_content)
            ):
                continue
            question = str(turn.get("question") or "").strip()
            answer = str(turn.get("answer") or "").strip()
            if question:
                history.append({"role": "user", "content": question})
            if answer:
                history.append({"role": "assistant", "content": answer})
        return history

    def _admitted_local_planner(self, provider_id: str, settings: ReasoningSettings) -> bool:
        """The admitted local planner is registered at startup from its deployment, not persisted
        as a provider setting. It counts as enabled when that registration exists; its gateway
        still refuses any task family the deployment's evaluation did not admit."""
        if provider_id != "local_ecology":
            return False
        try:
            return self.registry_factory(settings).get(provider_id) is not None
        except Exception:
            return False

    def _history_for_packet(
        self,
        conversation_id: str | None,
        packet: EvidencePacket,
        context_scope: dict | None = None,
    ) -> list[dict[str, str]]:
        if covenant_blocks_untyped_prose(packet.covenant):
            return []
        return self._conversation_history(
            conversation_id,
            allow_transcript=packet.permissions.transcript_included,
            allow_memory_content=packet.permissions.memory_content_included,
            context_scope=context_scope,
        )

    def _issue_token(self, context: _TurnContext, *, stage: int) -> str:
        token = secrets.token_urlsafe(32)
        with self._prepared_lock:
            self._expire_tokens_locked()
            self._prepared[token] = _PreparedTurn(
                context=context,
                stage=stage,
                expires_monotonic=time.monotonic() + self.prepare_ttl_seconds,
            )
        return token

    def _consume_token(self, token: str) -> _PreparedTurn:
        normalized = str(token or "").strip()
        with self._prepared_lock:
            self._expire_tokens_locked()
            prepared = self._prepared.pop(normalized, None)
        if prepared is None:
            raise ValueError("prepare token is invalid, expired, or already used")
        return prepared

    def _expire_tokens_locked(self) -> None:
        now = time.monotonic()
        self._prepared = {
            token: prepared
            for token, prepared in self._prepared.items()
            if prepared.expires_monotonic > now
        }

    def _prepared_payload(self, token: str, context: _TurnContext, *, stage: int) -> dict[str, Any]:
        self._check_local_context(context, external=True)
        return {
            "version": "0.2",
            "mode": "host_managed_reasoning",
            "prepare_token": token,
            "expires_in_seconds": round(self.prepare_ttl_seconds),
            "stage": stage,
            "conversation_id": context.conversation_prepared["conversation"]["id"],
            "event_id": context.event.get("id"),
            "provider_id": context.requested_provider_id,
            "model_id": context.model_id,
            "system_prompt": context.compiled.system_prompt,
            "user_prompt": context.compiled.user_prompt,
            "evidence_packet": _prepared_packet(context.packet, context.compiled).model_dump(mode="json"),
            "response_schema": context.compiled.response_schema,
            "prompt_hash": context.compiled.prompt_hash,
            "raw_audio_included": False,
        }


def _provider_locality(
    provider_id: str,
    model_id: str | None,
    settings: ReasoningSettings,
) -> ProviderLocality:
    # local_ecology is registered only for a loopback endpoint (registry.py refuses any other).
    if provider_id in {"local_structured", "oida_moss", "local_ecology"}:
        return ProviderLocality.LOCAL
    configured = settings.providers.get(provider_id)
    if provider_id == "ollama":
        if str(model_id or "").lower().endswith("cloud"):
            return ProviderLocality.EXTERNAL
        if configured and configured.base_url:
            try:
                return ProviderLocality(endpoint_locality(configured.base_url))
            except ValueError:
                return ProviderLocality.UNKNOWN
        return ProviderLocality.LOCAL
    if configured and configured.base_url and configured.kind.value in {
        "openai_compatible",
        "google",
    }:
        try:
            return ProviderLocality(endpoint_locality(configured.base_url))
        except ValueError:
            return ProviderLocality.UNKNOWN
    # Host CLIs and OpenCode can use an upstream subscription/model even when
    # their local transport is loopback. Treat their evidence boundary as
    # external/unknown; raw audio is still never included.
    if provider_id in {"codex", "claude", "hermes", "openclaw", "opencode"}:
        return ProviderLocality.UNKNOWN
    return configured.locality if configured else ProviderLocality.UNKNOWN


def _packet_with_relisten(packet: EvidencePacket, sidecar: dict[str, Any]) -> EvidencePacket:
    ref = f"relisten:{sidecar.get('id')}:observation:0"
    shared = bool(sidecar.get("observation_shared_to_reasoner"))
    observation = (
        safe_external_text(sidecar.get("observation"), limit=12_000)
        if shared
        else "A local targeted pass ran, but its free-form observation was not shared with this reasoner."
    )
    if not observation:
        observation = "The local targeted pass returned no shareable text."
    limitations = [
        text
        for value in list(sidecar.get("limitations") or [])[:16]
        if (text := safe_external_text(value, limit=2000))
    ]
    model = safe_external_text(sidecar.get("model"), limit=255)
    item = EvidenceItem(
        ref=ref,
        kind="relisten",
        value={
            "observation": observation,
            "limitations": limitations,
            "model": model,
            "time_range": sidecar.get("time_range"),
        },
        event_id=packet.primary_event_id,
        category="inferred",
        source="local_moss_targeted_relisten",
    )
    return packet.model_copy(update={"items": [*packet.items, item]})


def _without_action(response: ReasoningResponse, uncertainty: str) -> ReasoningResponse:
    values = list(response.uncertainties)
    if uncertainty and uncertainty not in values:
        values.append(_bounded_error(uncertainty))
    return response.model_copy(update={"requested_action": None, "uncertainties": values})


def _legacy_evidence(item: EvidenceItem) -> dict[str, str]:
    value = item.value if isinstance(item.value, str) else json.dumps(item.value, ensure_ascii=False, sort_keys=True)
    return {"kind": item.kind, "label": item.ref, "value": value[:12_000]}


def _memory_context_item(item: dict[str, Any]) -> dict[str, Any]:
    trace = item.get("trace") if isinstance(item.get("trace"), dict) else item
    return {
        "trace_id": trace.get("id"),
        "title": trace.get("title"),
        "score": item.get("score"),
        "basis": item.get("basis"),
    }


def _public_relisten(value: dict[str, Any] | None) -> dict[str, Any] | None:
    if not value:
        return None
    from oida.reasoning.relisten_projection import provenance_projection
    public = {
        key: value.get(key)
        for key in (
            "contract",
            "id",
            "base_event_id",
            "segment_ref",
            "conversation_id",
            "turn_id",
            "question",
            "parent_question",
            "time_range",
            "engine",
            "model",
            "observation",
            "limitations",
            "created_at",
            "sha256",
            "observation_shared_to_reasoner",
        )
    }
    for key, limit in (
        ("contract", 120),
        ("id", 255),
        ("base_event_id", 255),
        ("segment_ref", 255),
        ("conversation_id", 255),
        ("turn_id", 255),
        ("question", 4000),
        ("parent_question", 16_000),
        ("engine", 255),
        ("model", 255),
        ("observation", 12_000),
        ("created_at", 120),
        ("sha256", 160),
    ):
        public[key] = safe_external_text(public.get(key), limit=limit)
    public["limitations"] = [
        text
        for item in list(public.get("limitations") or [])[:16]
        if (text := safe_external_text(item, limit=2000))
    ]
    identity = value.get("listening_identity")
    if isinstance(identity, dict):
        public["listening_identity"] = {
            key: identity.get(key)
            for key in (
                "contract",
                "filename",
                "active",
                "sha256",
                "truncated",
                "application",
                "applied_to",
                "content_included",
                "role",
            )
        }
    public["provenance"] = provenance_projection(value)
    if not value.get("observation_shared_to_reasoner"):
        public["observation"] = None
        public["observation_withheld"] = True
    return public


def _redacted_comparison(event: dict[str, Any]) -> dict[str, Any]:
    # ConversationStore has the authoritative redaction path. This reduced
    # representation avoids duplicating arbitrary event internals here.
    aggregate = event.get("aggregate") if isinstance(event.get("aggregate"), dict) else {}
    return {
        "id": event.get("id"),
        "aggregate": {
            key: aggregate.get(key)
            for key in ("title", "short_summary")
            if aggregate.get(key) is not None
        },
    }


def _bounded_error(value: object) -> str:
    return safe_external_text(value, limit=1000) or (
        "The selected provider did not return a valid response; "
        "Oída used its local structured fallback."
    )


def _context_value(value: bool | None, default: bool) -> bool:
    return default if value is None else value
