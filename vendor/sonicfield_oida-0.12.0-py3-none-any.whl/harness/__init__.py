"""OIDA harness package."""

