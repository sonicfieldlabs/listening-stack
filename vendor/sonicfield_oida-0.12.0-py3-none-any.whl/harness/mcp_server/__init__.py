"""MCP stdio server package."""

