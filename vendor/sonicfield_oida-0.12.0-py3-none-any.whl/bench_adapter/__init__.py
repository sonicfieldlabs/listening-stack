"""AKOUO benchmark adapter package."""

