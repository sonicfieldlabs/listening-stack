"""Oída → GERM bridge over the shared akousma protocol.

Oída hears; GERM may cultivate. After an explicit handoff, Oída persists an
**akousma** (the sound's memory record) into the shared **Akousmata** store and hands GERM an
``akousma_id`` via a deep link. The three UI buttons map to three modes:

- ``sound``   — "open as sound":    load the listened fragment as an audio source in GERM.
- ``prompt``  — "open as prompt":   open the listening result as a generation prompt in GERM.
- ``lineage`` — "explore lineage":  open GERM's ancestry explorer on this akousma.

Requires the ``akousma`` package (earworm/packages/py-akousma).
"""

from __future__ import annotations

import os
import re
import time
from typing import Any, Literal
from urllib.parse import urlencode

import akousma

from oida.listening_identity import (
    LISTENING_IDENTITY_CONTRACT,
    LISTENING_IDENTITY_FILENAME,
    LISTENING_IDENTITY_ROLE,
)

MODES = ("sound", "prompt", "lineage")


class GermNotConfiguredError(RuntimeError):
    """Raised when a caller requests an optional GERM handoff without opting in."""


def germ_capability() -> dict[str, Any]:
    """Describe GERM as an optional handoff target without probing the network."""

    configured_url = str(os.getenv("OIDA_GERM_URL") or "").strip()
    enabled_value = str(os.getenv("OIDA_GERM_ENABLED") or "").strip().lower()
    enabled = bool(configured_url) and (
        enabled_value in {"1", "true", "yes", "on"} if enabled_value else True
    )
    return {
        "optional": True,
        "configured": bool(configured_url),
        "enabled": enabled,
        "base_url": configured_url.rstrip("/") if enabled and configured_url else None,
        "reachable": None,
        "reachability_note": "Oída does not contact an optional GERM service during capability discovery.",
        "modes": list(MODES),
        "handoff_requires_explicit_action": True,
    }


def germ_base_url() -> str:
    """Return the explicitly enabled GERM URL; never invent an installation."""
    capability = germ_capability()
    if not capability["enabled"] or not capability["base_url"]:
        raise GermNotConfiguredError(
            "GERM is optional and is not configured; set OIDA_GERM_URL before a handoff"
        )
    return str(capability["base_url"])


def germ_deep_link(akousma_id: str, mode: str) -> str:
    if mode not in MODES:
        raise ValueError(f"mode must be one of {MODES}, got {mode!r}")
    query = urlencode({"akousma": akousma_id, "mode": mode})
    return f"{germ_base_url()}/import?{query}"


# oída's internal source vocabulary is underscored (memory.py); the akousma
# provenance.origin enum is hyphenated. Normalize before validation so an
# unmapped origin cannot fail store.put.
_ORIGIN_ALIASES = {
    "live_input": "live-input",
    "system_output": "system-output",
    "buffer": "live-input",
    "external_stream": "system-output",
    "external-stream": "system-output",
}


def _normalize_origin(origin: str) -> str:
    origin = (origin or "file").strip().lower()
    return _ORIGIN_ALIASES.get(origin, origin.replace("_", "-"))


def _origin_to_source_type(origin: str) -> str:
    """Map oída's capture origin to Earworm's provenance source_type vocabulary."""
    return {
        "live-input": "recorded",
        "system-output": "recorded",
        "file": "imported",
        "generated": "generated",
    }.get(origin, "unknown")


AKOUO_CONTRACT = "akouo/v0.9"
OIDA_LISTENING_CONTRACT = "oida/listening-event/v0.3"
OIDA_HUMAN_LISTENING_CONTRACT = "oida/human-listening/v0.1"


def _envelope_listening(listening: dict[str, Any]) -> dict[str, Any]:
    """Wrap raw producer payloads in the akousma spec v1.1 listening envelope
    (``{contract?, created_at, summary?, payload}``). Entries already enveloped
    pass through untouched; akouo.* entries get the contract pin."""
    wrapped: dict[str, Any] = {}
    for namespace, value in (listening or {}).items():
        if (
            isinstance(value, dict)
            and "payload" in value
            and set(value) <= {"contract", "created_at", "summary", "payload"}
        ):
            wrapped[namespace] = value
            continue
        entry: dict[str, Any] = {
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "payload": value,
        }
        if namespace.startswith("akouo."):
            entry["contract"] = AKOUO_CONTRACT
        elif namespace == "oida.listen":
            entry["contract"] = OIDA_LISTENING_CONTRACT
        if isinstance(value, dict):
            for key in ("summary", "caption", "brief", "main_reading"):
                text = value.get(key)
                if isinstance(text, str) and text.strip():
                    entry["summary"] = text.strip()
                    break
        wrapped[namespace] = entry
    return wrapped


def _pointer_token(value: str) -> str:
    return value.replace("~", "~0").replace("/", "~1")


def _auditum_from_listening(
    listening: dict[str, Any],
    *,
    covenant: dict[str, Any] | None = None,
    disagreements: list[dict[str, Any]] | None = None,
    actions: list[dict[str, Any]] | None = None,
) -> dict[str, Any] | None:
    """Derive one attributable auditum without inventing an ear swarm.

    Route reports remain distinct, but they share the single ``oida`` listener
    identity. A namespace is a report boundary, not a new agent.
    """
    if not listening:
        return None
    listenings: list[dict[str, Any]] = []
    namespace_ids: dict[str, str] = {}
    honest_absences: list[dict[str, Any]] = []
    seen_absences: set[tuple[str, str, str, str | None]] = set()
    route_decisions: list[dict[str, Any]] = []
    seen_decisions: set[str] = set()
    for index, (namespace, entry) in enumerate(listening.items()):
        if not isinstance(entry, dict):
            continue
        payload = entry.get("payload") if isinstance(entry.get("payload"), dict) else {}
        listening_id = f"lst_{index + 1}_{re.sub(r'[^a-z0-9]+', '_', namespace.lower()).strip('_') or 'report'}"
        namespace_ids[namespace] = listening_id
        token = _pointer_token(namespace)
        contract = str(
            entry.get("contract") or payload.get("contract") or OIDA_LISTENING_CONTRACT
        )
        report: dict[str, Any] = {
            "listening_id": listening_id,
            "listener_id": "oida",
            "listener_type": "agent",
            "created_at": str(
                entry.get("created_at")
                or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            ),
            "report_namespace": namespace,
            "contract": contract,
        }
        if isinstance(payload.get("listening_context"), dict):
            report["context_ref"] = f"#/listening/{token}/payload/listening_context"
        if isinstance(payload.get("listening_provenance"), dict):
            report["listening_provenance_ref"] = (
                f"#/listening/{token}/payload/listening_provenance"
            )
        if isinstance(payload.get("apparatus"), dict):
            report["apparatus_ref"] = f"#/listening/{token}/payload/apparatus"
        if isinstance(payload.get("claim_summary"), dict):
            report["claim_set_ref"] = f"#/listening/{token}/payload/claim_summary"
        elif isinstance(payload.get("listening_claims"), dict):
            report["claim_set_ref"] = f"#/listening/{token}/payload/listening_claims"
        if covenant:
            report["covenant_ref"] = "#/covenant"
        route_ids: list[str] = []
        if isinstance(payload.get("route_id"), str):
            route_ids.append(payload["route_id"])
        if isinstance(payload.get("routes"), list):
            route_ids.extend(
                str(route.get("route_id"))
                for route in payload["routes"]
                if isinstance(route, dict) and route.get("route_id")
            )
        if namespace.startswith("akouo."):
            route_ids.append(namespace.removeprefix("akouo."))
        if route_ids:
            report["route"] = list(dict.fromkeys(route_ids))
        listenings.append(report)

        context = (
            payload.get("listening_context")
            if isinstance(payload.get("listening_context"), dict)
            else {}
        )
        passes = (
            context.get("listening_passes")
            if isinstance(context.get("listening_passes"), list)
            else []
        )
        first_pass = next(
            (item for item in passes if isinstance(item, dict) and item.get("id")), None
        )
        if first_pass:
            report["listening_pass_ref"] = str(first_pass["id"])
        producer_decisions = (
            context.get("route_decisions")
            if isinstance(context.get("route_decisions"), list)
            else []
        )
        decision_refs: list[str] = []
        for producer in producer_decisions:
            if not isinstance(producer, dict):
                continue
            producer_id = str(producer.get("id") or "").strip()
            if not producer_id:
                continue
            decision_refs.append(producer_id)
            if producer_id in seen_decisions:
                continue
            authority = (
                producer.get("authority")
                if isinstance(producer.get("authority"), dict)
                else {}
            )
            route_decisions.append(
                akousma.route_decision(
                    producer_id,
                    gate=str(producer.get("gate") or "input"),
                    outcome=str(producer.get("outcome") or "proceed"),
                    subject=str(producer.get("subject") or "listening request"),
                    reason=str(
                        producer.get("reason")
                        or "The accountable route recorded this decision."
                    ),
                    actor=str(authority.get("actor") or "oida-gateway"),
                    decided_at=str(
                        producer.get("decided_at")
                        or entry.get("created_at")
                        or "unknown"
                    ),
                    producer_contract=AKOUO_CONTRACT,
                    producer_decision_ref=producer_id,
                    covenant_ref=str(authority.get("covenant_ref") or "") or None,
                    granted_by=str(authority.get("granted_by") or "") or None,
                    requires_confirmation=bool(
                        authority.get("requires_confirmation", False)
                    ),
                    reversible=bool(authority.get("reversible", True)),
                    note=str(producer.get("note") or "") or None,
                )
            )
            seen_decisions.add(producer_id)
        if decision_refs:
            report["route_decision_refs"] = list(dict.fromkeys(decision_refs))
        for absence in context.get("honest_absences", []):
            if not isinstance(absence, dict):
                continue
            kind = str(absence.get("kind") or "unavailable")
            if kind not in {
                "unavailable",
                "withheld",
                "refused",
                "not_retained",
                "forgotten",
            }:
                continue
            subject = str(absence.get("subject") or "").strip()
            attributed_to = str(absence.get("attributed_to") or "").strip()
            key = (kind, subject, attributed_to, listening_id)
            if not subject or not attributed_to or key in seen_absences:
                continue
            seen_absences.add(key)
            item: dict[str, Any] = {
                "id": f"abs_{len(honest_absences) + 1}",
                "kind": kind,
                "subject": subject,
                "attributed_to": attributed_to,
                "listening_id": listening_id,
            }
            for field in ("count", "note"):
                if field in absence:
                    item[field] = absence[field]
            honest_absences.append(item)

    if not listenings:
        return None
    if not route_decisions:
        fallback = akousma.route_decision(
            "decision_akousma_registration",
            gate="memory",
            outcome="proceed",
            subject="akousma registration",
            reason="An explicit memory or handoff request opened the accountable-memory route.",
            actor="oida",
            producer_contract=AKOUO_CONTRACT,
            producer_decision_ref="decision_akousma_registration",
            granted_by="explicit memory or handoff request",
            requires_confirmation=False,
            reversible=True,
        )
        route_decisions.append(fallback)
        for report in listenings:
            report["route_decision_refs"] = [fallback["decision_id"]]

    covenant_id = str((covenant or {}).get("id") or "covenant")
    for withheld in (covenant or {}).get("withheld", []):
        if not isinstance(withheld, dict):
            continue
        subject = str(withheld.get("subject") or "").strip()
        rule = str(withheld.get("rule") or "withheld").strip()
        attributed_to = f"{covenant_id}:{rule}"
        key = ("withheld", subject, attributed_to, None)
        if not subject or key in seen_absences:
            continue
        seen_absences.add(key)
        honest_absences.append(
            {
                "id": f"abs_{len(honest_absences) + 1}",
                "kind": "withheld",
                "subject": subject,
                "attributed_to": attributed_to,
                "rule": rule,
                "count": withheld.get("count")
                if isinstance(withheld.get("count"), int)
                else 1,
            }
        )

    checked_disagreements: list[dict[str, Any]] = []
    known_ids = {item["listening_id"] for item in listenings}
    for index, disagreement in enumerate(disagreements or []):
        if not isinstance(disagreement, dict):
            continue
        raw_ids = (
            disagreement.get("listening_ids")
            if isinstance(disagreement.get("listening_ids"), list)
            else []
        )
        ids = [namespace_ids.get(str(value), str(value)) for value in raw_ids]
        ids = list(dict.fromkeys(value for value in ids if value in known_ids))
        positions: list[dict[str, Any]] = []
        for position in disagreement.get("positions", []):
            if not isinstance(position, dict):
                continue
            position_id = namespace_ids.get(
                str(position.get("listening_id")),
                str(position.get("listening_id") or ""),
            )
            statement = str(position.get("statement") or "").strip()
            if position_id not in ids or not statement:
                continue
            item = {"listening_id": position_id, "statement": statement}
            category = position.get("claim_category")
            if category in {
                "heard",
                "measured",
                "inferred",
                "interpreted",
                "speculative",
                "undetermined",
            }:
                item["claim_category"] = category
            positions.append(item)
        subject = str(disagreement.get("subject") or "").strip()
        if len(ids) < 2 or len(positions) < 2 or not subject:
            continue
        checked_disagreements.append(
            {
                "id": str(disagreement.get("id") or f"dis_{index + 1}"),
                "subject": subject,
                "listening_ids": ids,
                "positions": positions,
                "status": disagreement.get("status")
                if disagreement.get("status")
                in {"preserved", "resolved", "undetermined"}
                else "preserved",
                "resolution_note": disagreement.get("resolution_note"),
            }
        )

    if not route_decisions:
        route_decisions.append(
            akousma.route_decision(
                "decision_oida_listening_record",
                gate="memory",
                outcome="proceed",
                subject="Oída listening account",
                reason="An explicit local action requested that this completed listening be retained.",
                actor="oida",
                decided_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                listening_id=listenings[0]["listening_id"] if listenings else None,
                granted_by="explicit local remember action",
                requires_confirmation=False,
                reversible=True,
            )
        )

    return akousma.auditum(
        listenings=listenings,
        disagreements=checked_disagreements,
        honest_absences=honest_absences,
        actions=actions or [],
        route_decisions=route_decisions,
    )


def _derive_summary(listening: dict[str, Any]) -> str | None:
    """Skimmable one-liner for the record, preferring oída's own signal caption."""
    for namespace in ("oida.signal", "oida.moss", "akouo.describe"):
        entry = listening.get(namespace)
        if isinstance(entry, dict):
            if isinstance(entry.get("summary"), str) and entry["summary"].strip():
                return entry["summary"].strip()
            payload = (
                entry.get("payload")
                if isinstance(entry.get("payload"), dict)
                else entry
            )
            for key in ("caption", "brief", "summary", "main_reading"):
                text = payload.get(key) if isinstance(payload, dict) else None
                if isinstance(text, str) and text.strip():
                    return text.strip()
    return None


def _checked_location(value: dict[str, Any] | None) -> dict[str, Any] | None:
    """Validate a spec v1.2 location dict through the akousma builder."""
    if not value:
        return None
    label = value.get("label")
    return akousma.location(
        value.get("lat"),
        value.get("lon"),
        accuracy_m=value.get("accuracy_m"),
        altitude_m=value.get("altitude_m"),
        label=str(label).strip() or None if label is not None else None,
        source=value.get("source") or "gps",
        captured_at=value.get("captured_at"),
    )


def _checked_capture(value: dict[str, Any] | None) -> dict[str, Any] | None:
    """Validate a spec v1.2 capture dict through the akousma builder."""
    if not value:
        return None
    return akousma.capture(
        value.get("direction"),
        seconds=value.get("seconds"),
        trigger=value.get("trigger"),
        armed_at=value.get("armed_at"),
        triggered_at=value.get("triggered_at"),
    )


def _checked_covenant(value: dict[str, Any] | None) -> dict[str, Any] | None:
    """Validate a spec v1.3 covenant dict through the akousma builder. The
    block carries identity and honest absence — never the covenant's text."""
    if not value:
        return None
    return akousma.covenant(
        value.get("id"),
        name=value.get("name"),
        version=value.get("version"),
        contract=value.get("contract") or AKOUO_CONTRACT,
        sha256_hex=value.get("sha256"),
        extends=value.get("extends"),
        rules_applied=value.get("rules_applied"),
        withheld=value.get("withheld"),
        commitments=value.get("commitments"),
        note=value.get("note"),
    )


def _checked_listening_identity(value: dict[str, Any] | None) -> dict[str, Any] | None:
    """Keep only content-free identity provenance in a shared akousma."""

    if not isinstance(value, dict):
        return None
    digest = str(value.get("sha256") or "").lower()
    declared = str(value.get("declared_sha256") or "").lower()
    block: dict[str, Any] = {
        "contract": LISTENING_IDENTITY_CONTRACT,
        "filename": LISTENING_IDENTITY_FILENAME,
        "active": value.get("active") is True,
        "sha256": digest if re.fullmatch(r"[0-9a-f]{64}", digest) else None,
        "truncated": value.get("truncated") is True,
        "application": str(value.get("application") or "unknown")[:80],
        "applied_to": [
            str(item)[:120]
            for item in value.get("applied_to", [])[:32]
            if isinstance(item, str) and item
        ]
        if isinstance(value.get("applied_to"), list)
        else [],
        "content_included": False,
        "role": LISTENING_IDENTITY_ROLE,
    }
    if re.fullmatch(r"[0-9a-f]{64}", declared):
        block["declared_sha256"] = declared
    return block


def build_decision_akousma(
    outcome: dict[str, Any],
    *,
    source_type: str = "unknown",
    origin: str = "file",
    session_id: str | None = None,
) -> dict[str, Any]:
    """Build a content-free Earworm v0.6 record for a pre-listening decision."""

    producer = (
        outcome.get("route_decision")
        if isinstance(outcome.get("route_decision"), dict)
        else {}
    )
    authority = (
        producer.get("authority") if isinstance(producer.get("authority"), dict) else {}
    )
    receipt = outcome.get("receipt") if isinstance(outcome.get("receipt"), dict) else {}
    decision = akousma.route_decision(
        str(producer.get("id") or f"decision_{outcome.get('id') or 'oida'}"),
        gate=str(producer.get("gate") or "input"),
        outcome=str(producer.get("outcome") or "refuse"),
        subject=str(
            producer.get("subject") or outcome.get("subject") or "listening request"
        ),
        reason=str(
            producer.get("reason")
            or "The listening request was refused before perception."
        ),
        actor=str(authority.get("actor") or "oida-covenant-gate"),
        decided_at=str(
            producer.get("decided_at") or outcome.get("completed_at") or "unknown"
        ),
        producer_contract=AKOUO_CONTRACT,
        producer_decision_ref=str(producer.get("id") or "") or None,
        covenant_ref=str(authority.get("covenant_ref") or "") or None,
        granted_by=str(authority.get("granted_by") or "") or None,
        requires_confirmation=bool(authority.get("requires_confirmation", False)),
        reversible=bool(authority.get("reversible", True)),
        note=str(producer.get("note") or "") or None,
    )
    if receipt:
        decision["receipt"] = {
            "created_at": str(
                receipt.get("created_at") or outcome.get("completed_at") or "unknown"
            ),
            "actor": str(receipt.get("actor") or "oida-covenant-gate"),
            "result": str(receipt.get("result") or "listening did not begin"),
            "recovery": str(receipt.get("recovery") or "") or None,
        }
    absences: list[dict[str, Any]] = []
    for index, absence in enumerate(outcome.get("honest_absences") or []):
        if not isinstance(absence, dict):
            continue
        absences.append(
            {
                "id": f"absence_{index + 1}",
                "kind": str(absence.get("kind") or "refused"),
                "subject": str(
                    absence.get("subject")
                    or outcome.get("subject")
                    or "listening request"
                ),
                "attributed_to": str(absence.get("attributed_to") or "oida-gateway"),
                "listening_id": None,
                "count": int(absence.get("count") or 1),
                "note": str(absence.get("note") or "") or None,
            }
        )
    auditum = akousma.auditum(
        listenings=[],
        disagreements=[],
        honest_absences=absences,
        actions=[],
        route_decisions=[decision],
    )
    record = akousma.new_akousma(
        audio=None,
        subject=str(outcome.get("subject") or "listening request"),
        originating_app="oida",
        source_type=source_type,
        origin=_normalize_origin(origin),
        operation="route-decision",
        tags=["decision-only", "pre-listening-refusal"],
        session_id=session_id,
        summary="Listening was refused before an acoustic listening pass began.",
        covenant=_checked_covenant(
            outcome.get("covenant")
            if isinstance(outcome.get("covenant"), dict)
            else None
        ),
        auditum=auditum,
        extensions={
            "oida.route_outcome": {
                "contract": str(outcome.get("contract") or "oida/route-outcome/v0.1"),
                "outcome_id": str(outcome.get("id") or ""),
                "content_included": False,
            }
        },
    )
    record["provenance"]["consent_status"] = "restricted"
    record["provenance"]["capture_conditions"] = (
        "Listening was refused before an audio asset was captured or referenced."
    )
    record["provenance"]["rights_note"] = (
        "Decision metadata only; no audio content is included."
    )
    return record


def build_akousma_from_listen(
    *,
    audio: dict[str, Any],
    listening: dict[str, Any] | None = None,
    origin: str = "file",
    device: str | None = None,
    session_id: str | None = None,
    tags: list[str] | None = None,
    summary: str | None = None,
    location: dict[str, Any] | None = None,
    capture: dict[str, Any] | None = None,
    covenant: dict[str, Any] | None = None,
    listening_identity: dict[str, Any] | None = None,
    disagreements: list[dict[str, Any]] | None = None,
    actions: list[dict[str, Any]] | None = None,
    auditum: dict[str, Any] | None = None,
    lineage: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a valid akousma record from an oída listen result.

    ``audio`` needs at least ``asset_id`` (and ideally ``uri``/``content_hash``/duration).
    ``listening`` is namespaced per producer, e.g. ``{"oida.signal": {...}, "akouo.describe": {...}}``;
    entries are wrapped in the current envelope with akouo.* entries pinned to the
    ``akouo/v0.9`` contract. ``location`` (where it was heard — consent-scoped) and
    ``capture`` (past/future direction + window seconds) are spec v1.2 blocks.

    ``lineage`` lets the caller declare what this listening descends from — see
    :func:`apply_declared_lineage`. Finding P1-02: a generated sound reviewed as a
    new subject was retained as an ordinary capture with an empty
    ``parent_akousma_ids``, so the join between a sound and the listening it was
    made from lived only in the caller's own run receipt, where no exporter could
    reach it. The akousma schema has carried ``parent_akousma_ids`` and typed
    ``relations`` since 1.x; nothing needed extending. What was missing was anyone
    telling the owner.
    """
    origin = _normalize_origin(origin)
    enveloped = _envelope_listening(listening or {})
    identity_extension = _checked_listening_identity(listening_identity)
    extensions = (
        {"oida.listening_identity": identity_extension} if identity_extension else None
    )
    record = akousma.new_akousma(
        audio=audio,
        originating_app="oida",
        source_type=_origin_to_source_type(origin),
        origin=origin,
        listening=enveloped,
        operation="listen",
        tags=tags,
        session_id=session_id,
        summary=summary or _derive_summary(enveloped),
        location=_checked_location(location),
        capture=_checked_capture(capture),
        covenant=_checked_covenant(covenant),
        auditum=auditum
        or _auditum_from_listening(
            enveloped,
            covenant=covenant,
            disagreements=disagreements,
            actions=actions,
        ),
        extensions=extensions,
    )
    if device:
        record["provenance"]["device"] = device
    if lineage:
        apply_declared_lineage(record, lineage)
    return record


#: Relation types the akousma schema defines. A declared lineage may only use
#: these; an unrecognised type is refused rather than coerced to "other", which
#: would make every unknown kinship look like the same deliberate choice.
DECLARED_RELATION_TYPES = (
    "variant_of",
    "response_to",
    "same_source_as",
    "recurrence_of",
    "series_with",
    "compares_with",
    "replaces",
    "other",
)


def apply_declared_lineage(record: dict[str, Any], declared: dict[str, Any]) -> None:
    """Record what the caller says this listening descends from.

    Finding P1-02. Oída already links ``same_source_as`` when it recognises a
    content hash it has seen before. That is kinship oída can *observe*. This is
    kinship only the caller knows: that this listening is a review of a sound
    generated from that earlier account. The Central holds that fact in its run
    receipt, and until now had no way to hand it to the owner that writes the
    record.

    Deliberately strict, because a lineage claim is an evidential one:

    * ``parent_akousma_ids`` must be a list of non-empty strings, and is merged
      rather than replaced, so an observed kinship is never overwritten by a
      declared one.
    * A relation's ``type`` must be one the schema defines. An unknown type is
      refused, not mapped to ``other``.
    * Nothing here invents a relation from proximity. The caller states it, and
      ``note`` should say on what basis, so the claim can be contested.
    """
    if not isinstance(declared, dict):
        raise ValueError("declared lineage must be an object")

    lineage = record.setdefault("lineage", {})
    parents = lineage.setdefault("parent_akousma_ids", [])

    for parent in declared.get("parent_akousma_ids") or []:
        if not isinstance(parent, str) or not parent.strip():
            raise ValueError(f"declared parent akousma id is not a usable string: {parent!r}")
        if parent == record.get("akousma_id"):
            raise ValueError("a record cannot be its own parent")
        if parent not in parents:
            parents.append(parent)

    relations = lineage.setdefault("relations", [])
    for relation in declared.get("relations") or []:
        if not isinstance(relation, dict):
            raise ValueError("a declared relation must be an object")
        kind = relation.get("type")
        target = relation.get("target_akousma_id")
        if kind not in DECLARED_RELATION_TYPES:
            raise ValueError(
                f"declared relation type {kind!r} is not one the akousma schema "
                f"defines ({', '.join(DECLARED_RELATION_TYPES)}). An unrecognised "
                "kinship is refused rather than recorded as 'other'."
            )
        if not isinstance(target, str) or not target.strip():
            raise ValueError("a declared relation needs a target_akousma_id")
        if any(
            r.get("type") == kind and r.get("target_akousma_id") == target
            for r in relations
        ):
            continue
        entry = akousma.relation(kind, target, note=relation.get("note") or "")
        relations.append(entry)

    if declared.get("operation"):
        # The operation that produced *this* record, e.g. "generation_review".
        # Left alone when absent: the default "listen" is usually correct.
        lineage["operation"] = str(declared["operation"])


def build_human_response_akousma(
    machine_record: dict[str, Any],
    machine_akousma_id: str,
    note: str,
    *,
    listener_id: str = "oida-local-human",
    display_name: str | None = None,
    privacy: str = "private",
) -> dict[str, Any]:
    """Build a separate human account linked to one machine listening.

    A note is attributable human testimony, but it is not automatically a
    ``heard`` claim. The linked machine record remains untouched, and
    ``same_source_as`` is asserted only because this builder copies the exact
    source identity from that record.
    """

    normalized_note = str(note or "").strip()
    normalized_listener = str(listener_id or "").strip()
    normalized_privacy = str(privacy or "private").strip().lower()
    if not normalized_note:
        raise ValueError("a human listening account requires a non-empty note")
    if not normalized_listener:
        raise ValueError("a human listening account requires a stable listener id")
    if normalized_privacy not in {"private", "shared"}:
        raise ValueError("human profile privacy must be private or shared")
    created_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    listening_id = f"lst_human_{re.sub(r'[^a-z0-9]+', '_', normalized_listener.lower()).strip('_') or 'local'}"
    decision = akousma.route_decision(
        f"decision_remember_{listening_id}",
        gate="memory",
        outcome="proceed",
        subject="human listening account",
        reason="A local person explicitly chose to retain this separate account.",
        actor=normalized_listener,
        decided_at=created_at,
        granted_by="explicit local remember action",
        requires_confirmation=False,
        reversible=True,
        listening_id=listening_id,
    )
    audio = (
        machine_record.get("audio")
        if isinstance(machine_record.get("audio"), dict)
        else None
    )
    auditum = akousma.auditum(
        listenings=[
            {
                "listening_id": listening_id,
                "listener_id": normalized_listener,
                "listener_type": "human",
                "created_at": created_at,
                "report_namespace": "oida.human",
                "contract": OIDA_HUMAN_LISTENING_CONTRACT,
                "route_decision_refs": [decision["decision_id"]],
                "note": normalized_note,
            }
        ],
        disagreements=[],
        honest_absences=(
            []
            if audio
            else [
                {
                    "id": f"absence_{listening_id}",
                    "kind": "unavailable",
                    "subject": "raw audio",
                    "attributed_to": "linked machine record",
                    "listening_id": listening_id,
                    "count": 1,
                    "note": "The source identity is linked, but raw audio is not present in this record.",
                }
            ]
        ),
        actions=[],
        route_decisions=[decision],
    )
    subject = (
        None
        if audio
        else str(machine_record.get("subject") or "linked listening event")
    )
    provenance = (
        machine_record.get("provenance")
        if isinstance(machine_record.get("provenance"), dict)
        else {}
    )
    relations = [
        akousma.relation(
            "response_to",
            machine_akousma_id,
            note="Separate human account made in response to the machine listening.",
        )
    ]
    if audio:
        relations.append(
            akousma.relation(
                "same_source_as",
                machine_akousma_id,
                note="The two records were created from the same verified source identity.",
            )
        )
    record = akousma.new_akousma(
        audio=dict(audio) if audio else None,
        subject=subject,
        originating_app="oida",
        source_type=str(provenance.get("source_type") or "unknown"),
        origin=str(provenance.get("origin") or "unknown"),
        listening={
            "oida.human": {
                "contract": OIDA_HUMAN_LISTENING_CONTRACT,
                "created_at": created_at,
                "summary": normalized_note,
                "payload": {
                    "note": normalized_note,
                    "heard_claimed": False,
                    "claims": [],
                    "response_to_akousma_id": machine_akousma_id,
                },
            }
        },
        relations=relations,
        tags=["human-listening", "linked-account"],
        session_id=str(machine_record.get("session_id") or "") or None,
        summary=normalized_note,
        auditum=auditum,
        extensions={
            "oida.human_profile": {
                "listener_id": normalized_listener,
                "display_name": (
                    str(display_name).strip()
                    if normalized_privacy == "shared" and display_name
                    else None
                ),
                "local_only": normalized_privacy != "shared",
            }
        },
    )
    human_meta: dict[str, Any] = {
        "owner_listener_id": normalized_listener,
        "privacy": normalized_privacy,
        "revision_root": record["akousma_id"],
    }
    if normalized_privacy == "shared" and display_name and str(display_name).strip():
        human_meta["display_name"] = str(display_name).strip()
    record["extensions"]["akousmata.app"] = {
        "listener": {"type": "human", "process": "oida_linked_account"},
        "human_record": human_meta,
    }
    return record


def _maybe_link_recurrence(
    record: dict[str, Any], store: "akousma.AkousmataStore"
) -> None:
    """When the same audio content already lives in the store, link the new record
    to the most recent holder as ``same_source_as`` (spec v1.1 relations). Best-effort:
    registration must never fail because kinship lookup did."""
    try:
        content_hash = str(record.get("audio", {}).get("content_hash") or "")
        if not content_hash or not hasattr(store, "find_by_hash"):
            return
        matches = [
            r
            for r in store.find_by_hash(content_hash)
            if r.get("akousma_id") != record.get("akousma_id")
        ]
        if not matches:
            return
        newest = matches[0]
        relations = record.setdefault("lineage", {}).setdefault("relations", [])
        if any(
            rel.get("target_akousma_id") == newest["akousma_id"] for rel in relations
        ):
            return
        relations.append(
            akousma.relation(
                "same_source_as",
                newest["akousma_id"],
                note="Same audio content hash already in the akousmata.",
            )
        )
    except Exception:
        pass


def _maybe_enrich_songid(record: dict[str, Any], audio: dict[str, Any]) -> None:
    """Attach ``extensions.songid`` when ``OIDA_SONGID`` is enabled. Best-effort:
    the handoff must never fail because identification did."""
    uri = str(audio.get("uri") or "")
    path = uri[7:] if uri.startswith("file://") else uri
    if not path:
        return
    try:
        from .songid import enrich_akousma as _enrich
        from .songid import songid_enabled

        if songid_enabled() and os.path.exists(path):
            _enrich(record, path)
    except Exception:
        pass


def persist_akousma(
    record: dict[str, Any],
    *,
    store: "akousma.AkousmataStore | None" = None,
) -> str:
    """Persist ``record`` to the shared akousmata store (with recurrence
    linking) and return its id. Used by the germ handoff and the remote ear."""
    owns_store = store is None
    store = store or akousma.AkousmataStore()
    try:
        _maybe_link_recurrence(record, store)
        return store.put(record)
    finally:
        if owns_store:
            store.close()


def handoff_to_germ(
    record: dict[str, Any],
    mode: str,
    *,
    store: "akousma.AkousmataStore | None" = None,
) -> dict[str, Any]:
    """Persist ``record`` to the shared akousmata store and return the germ deep link.

    Returns ``{"akousma_id", "mode", "germ_url"}``. Backing the three oída buttons.
    """
    if mode not in MODES:
        raise ValueError(f"mode must be one of {MODES}, got {mode!r}")
    germ_url = germ_deep_link(str(record.get("akousma_id") or ""), mode)
    akousma_id = persist_akousma(record, store=store)
    return {"akousma_id": akousma_id, "mode": mode, "germ_url": germ_url}


def build_germ_router():
    """FastAPI router backing the three oída→germ buttons. Imported lazily so this
    module stays usable without FastAPI (e.g. in cross-app tests)."""
    from fastapi import APIRouter, HTTPException
    from pydantic import BaseModel, ConfigDict

    # Must be a module global: with `from __future__ import annotations` FastAPI
    # resolves the route's string annotation through this module's globals, and a
    # function-local model silently degrades the JSON body into a query param.
    global GermHandoffRequest

    class GermHandoffRequest(BaseModel):
        model_config = ConfigDict(allow_inf_nan=False, extra="forbid", strict=True)

        mode: Literal["sound", "prompt", "lineage"]
        audio: dict[str, Any]
        listening: dict[str, Any] | None = None
        origin: str = "file"
        device: str | None = None
        session_id: str | None = None
        tags: list[str] | None = None
        summary: str | None = None
        location: dict[str, Any] | None = None
        capture: dict[str, Any] | None = None
        covenant: dict[str, Any] | None = None
        listening_identity: dict[str, Any] | None = None

    router = APIRouter(prefix="/germ", tags=["germ"])

    @router.post("/handoff")
    def germ_handoff(req: GermHandoffRequest) -> dict[str, Any]:
        try:
            record = build_akousma_from_listen(
                audio=req.audio,
                listening=req.listening,
                origin=req.origin,
                device=req.device,
                session_id=req.session_id,
                tags=req.tags,
                summary=req.summary,
                location=req.location,
                capture=req.capture,
                covenant=req.covenant,
                listening_identity=req.listening_identity,
            )
            _maybe_enrich_songid(record, req.audio)
            return handoff_to_germ(record, req.mode)
        except GermNotConfiguredError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except (TypeError, ValueError) as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @router.get("/link")
    def germ_link(akousma_id: str, mode: str = "lineage") -> dict[str, Any]:
        try:
            return {
                "akousma_id": akousma_id,
                "mode": mode,
                "germ_url": germ_deep_link(akousma_id, mode),
            }
        except GermNotConfiguredError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    return router
