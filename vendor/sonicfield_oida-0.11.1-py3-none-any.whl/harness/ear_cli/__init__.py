"""`ear` CLI package."""

